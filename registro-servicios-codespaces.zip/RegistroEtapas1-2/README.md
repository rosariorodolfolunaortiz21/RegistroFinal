# Registro de Servicios Sociales y Profesionales

Aplicación inicial full-stack con frontend HTML/CSS/JS, FastAPI, PostgreSQL y Nginx para GitHub Codespaces.

## Arranque en Codespaces

1. En la terminal, crea el archivo de configuración:
   ```bash
   cp .env.example .env
   ```
2. Edita `.env` y cambia `POSTGRES_PASSWORD`, `DATABASE_URL` (usa exactamente la misma contraseña), `SECRET_KEY` y `ADMIN_PASSWORD`. La contraseña de administrador debe tener al menos 12 caracteres.
3. Construye e inicia:
   ```bash
   docker compose up --build -d
   ```
4. Comprueba servicios:
   ```bash
   docker compose ps
   docker compose logs --tail=50 backend
   ```
5. En la pestaña **Ports**, abre el puerto `8080`. Si no aparece, usa **Add Port / Forward a Port** para reenviar `8080`. No escribas el número en la terminal.
6. La API está en `/docs` del puerto 8000 y la comprobación de conexión en `/health/ready`.

## Credenciales iniciales

Se crean a partir de `ADMIN_EMAIL` y `ADMIN_PASSWORD` en `.env`. No se publican credenciales predeterminadas. No compartas el archivo `.env`.

## Funciones implementadas

Registro e inicio de sesión con JWT y hashing Argon2, catálogo público de publicaciones aprobadas, creación de propuestas, gestión de empresas por administrador, administración básica de usuarios, revisión por moderador con comprobación de empresa asignada, PostgreSQL persistente y documentación OpenAPI.

## Diagnóstico rápido

```bash
docker compose ps
docker compose logs --tail=80 backend
docker compose logs --tail=50 db
curl -i http://localhost:8000/health/ready
curl -i http://localhost:8080/
```

Si cambiaste la contraseña de PostgreSQL después de crear el volumen, la variable no cambia la contraseña ya guardada en el volumen. No borres `postgres_data` si necesitas conservar información; revisa las credenciales y la base de datos antes de hacer cambios destructivos.

Este proyecto es una base funcional inicial, no una auditoría de seguridad ni una validación de producción. Revisa y prueba en el entorno de destino antes de publicar.
