from datetime import datetime,timedelta,timezone
import jwt
from pwdlib import PasswordHash
from .config import settings
hasher=PasswordHash.recommended()
def hash_password(p): return hasher.hash(p)
def verify_password(p,h):
    try: return hasher.verify(p,h)
    except Exception: return False
def token(uid):
    n=datetime.now(timezone.utc)
    return jwt.encode({"sub":str(uid),"iat":n,"exp":n+timedelta(minutes=settings.access_token_minutes)},settings.secret_key,algorithm="HS256")
