from pydantic_settings import BaseSettings,SettingsConfigDict
class Settings(BaseSettings):
    database_url:str="postgresql+psycopg://registro:registro@db:5432/registro_servicios"
    secret_key:str="development-secret-change-this-key-32-chars"
    access_token_minutes:int=60
    admin_email:str="admin@example.com"
    admin_password:str="ChangeThisAdminPassword123!"
    model_config=SettingsConfigDict(env_file=".env",extra="ignore")
settings=Settings()
