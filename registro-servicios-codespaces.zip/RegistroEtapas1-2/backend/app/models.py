from datetime import datetime,timezone
from sqlalchemy import String,Text,Boolean,DateTime,ForeignKey,UniqueConstraint
from sqlalchemy.orm import Mapped,mapped_column
from .database import Base
def now(): return datetime.now(timezone.utc)
class User(Base):
    __tablename__="users"
    id:Mapped[int]=mapped_column(primary_key=True)
    email:Mapped[str]=mapped_column(String(255),unique=True,index=True)
    first_name:Mapped[str]=mapped_column(String(100))
    last_name:Mapped[str]=mapped_column(String(100))
    password_hash:Mapped[str]=mapped_column(String(255))
    role:Mapped[str]=mapped_column(String(20),default="user")
    is_active:Mapped[bool]=mapped_column(Boolean,default=True)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class Company(Base):
    __tablename__="companies"
    id:Mapped[int]=mapped_column(primary_key=True)
    name:Mapped[str]=mapped_column(String(200),index=True)
    description:Mapped[str]=mapped_column(Text,default="")
    contact_email:Mapped[str|None]=mapped_column(String(255),nullable=True)
    is_active:Mapped[bool]=mapped_column(Boolean,default=True)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class Assignment(Base):
    __tablename__="moderator_assignments"
    __table_args__=(UniqueConstraint("user_id","company_id"),)
    id:Mapped[int]=mapped_column(primary_key=True)
    user_id:Mapped[int]=mapped_column(ForeignKey("users.id"))
    company_id:Mapped[int]=mapped_column(ForeignKey("companies.id"))
class Publication(Base):
    __tablename__="publications"
    id:Mapped[int]=mapped_column(primary_key=True)
    title:Mapped[str]=mapped_column(String(200),index=True)
    description:Mapped[str]=mapped_column(Text)
    service_type:Mapped[str]=mapped_column(String(100),index=True)
    company_id:Mapped[int]=mapped_column(ForeignKey("companies.id"))
    creator_id:Mapped[int]=mapped_column(ForeignKey("users.id"))
    status:Mapped[str]=mapped_column(String(30),default="pending")
    is_active:Mapped[bool]=mapped_column(Boolean,default=True)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
