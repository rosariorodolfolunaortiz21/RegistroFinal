from contextlib import asynccontextmanager
from fastapi import FastAPI,Depends,HTTPException,Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer,HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from sqlalchemy import or_
import jwt
from .database import Base,engine,SessionLocal,get_db,wait_db
from .models import User,Company,Assignment,Publication
from .security import hash_password,verify_password,token
from .config import settings
from pydantic import BaseModel,EmailStr,Field
from typing import Optional

@asynccontextmanager
async def lifespan(app):
    wait_db()
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        admin=db.query(User).filter_by(email=settings.admin_email.lower()).first()
        if not admin:
            if len(settings.admin_password)<12 or settings.admin_password.startswith("CAMBIA_"):
                raise RuntimeError("Configura ADMIN_PASSWORD en .env (12 caracteres o más).")
            db.add(User(email=settings.admin_email.lower(),first_name="Administrador",last_name="Inicial",password_hash=hash_password(settings.admin_password),role="admin"))
            db.commit()
    yield
app=FastAPI(title="Registro de Servicios Sociales y Profesionales",version="1.0.0",lifespan=lifespan)
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_credentials=False,allow_methods=["*"],allow_headers=["*"])
bearer=HTTPBearer(auto_error=False)
def current(creds:HTTPAuthorizationCredentials=Depends(bearer),db:Session=Depends(get_db)):
    if not creds: raise HTTPException(401,"Inicia sesión")
    try: uid=int(jwt.decode(creds.credentials,settings.secret_key,algorithms=["HS256"])["sub"])
    except Exception: raise HTTPException(401,"Token inválido o expirado")
    u=db.get(User,uid)
    if not u or not u.is_active: raise HTTPException(401,"Usuario inactivo")
    return u
def roles(*allowed):
    def check(u:User=Depends(current)):
        if u.role not in allowed: raise HTTPException(403,"No tienes permisos")
        return u
    return check
class Register(BaseModel):
    email:EmailStr
    first_name:str=Field(min_length=1,max_length=100)
    last_name:str=Field(min_length=1,max_length=100)
    password:str=Field(min_length=10,max_length=128)
class Login(BaseModel):
    email:EmailStr
    password:str
class CompanyIn(BaseModel):
    name:str=Field(min_length=2,max_length=200)
    description:str=""
    contact_email:Optional[EmailStr]=None
class PubIn(BaseModel):
    title:str=Field(min_length=3,max_length=200)
    description:str=Field(min_length=5)
    service_type:str
    company_id:int
@app.get("/health/live")
def live(): return {"status":"alive"}
@app.get("/health/ready")
def ready():
    from sqlalchemy import text
    with engine.connect() as c: c.execute(text("SELECT 1"))
    return {"status":"ready","database":"connected"}
@app.post("/api/auth/register")
def register(data:Register,db:Session=Depends(get_db)):
    email=str(data.email).lower()
    if db.query(User).filter_by(email=email).first(): raise HTTPException(409,"Ese correo ya está registrado")
    u=User(email=email,first_name=data.first_name,last_name=data.last_name,password_hash=hash_password(data.password),role="user")
    db.add(u); db.commit(); db.refresh(u)
    return {"id":u.id,"email":u.email,"role":u.role}
@app.post("/api/auth/login")
def login(data:Login,db:Session=Depends(get_db)):
    u=db.query(User).filter_by(email=str(data.email).lower()).first()
    if not u or not u.is_active or not verify_password(data.password,u.password_hash): raise HTTPException(401,"Correo o contraseña incorrectos")
    return {"access_token":token(u.id),"token_type":"bearer","user":{"id":u.id,"email":u.email,"first_name":u.first_name,"last_name":u.last_name,"role":u.role}}
@app.get("/api/me")
def me(u:User=Depends(current)): return {"id":u.id,"email":u.email,"first_name":u.first_name,"last_name":u.last_name,"role":u.role}
@app.get("/api/companies")
def companies(db:Session=Depends(get_db)):
    return [{"id":c.id,"name":c.name,"description":c.description,"contact_email":c.contact_email} for c in db.query(Company).filter_by(is_active=True).all()]
@app.post("/api/companies")
def create_company(data:CompanyIn,u:User=Depends(roles("admin")),db:Session=Depends(get_db)):
    c=Company(**data.model_dump()); db.add(c); db.commit(); db.refresh(c); return {"id":c.id,"name":c.name}
@app.get("/api/publications")
def publications(q:str="",service_type:str="",company_id:int|None=None,page:int=Query(1,ge=1),size:int=Query(20,ge=1,le=100),db:Session=Depends(get_db)):
    query=db.query(Publication).filter_by(status="published",is_active=True)
    if q: query=query.filter(Publication.title.ilike(f"%{q}%"))
    if service_type: query=query.filter(Publication.service_type==service_type)
    if company_id: query=query.filter(Publication.company_id==company_id)
    rows=query.order_by(Publication.created_at.desc()).offset((page-1)*size).limit(size).all()
    return [{"id":p.id,"title":p.title,"description":p.description,"service_type":p.service_type,"company_id":p.company_id} for p in rows]
@app.post("/api/publications")
def create_publication(data:PubIn,u:User=Depends(current),db:Session=Depends(get_db)):
    if not db.query(Company).filter_by(id=data.company_id,is_active=True).first(): raise HTTPException(404,"Empresa no encontrada")
    p=Publication(**data.model_dump(),creator_id=u.id,status="pending"); db.add(p); db.commit(); db.refresh(p)
    return {"id":p.id,"status":p.status,"message":"Enviada a revisión"}
@app.get("/api/admin/users")
def users(u:User=Depends(roles("admin")),db:Session=Depends(get_db)):
    return [{"id":x.id,"email":x.email,"first_name":x.first_name,"last_name":x.last_name,"role":x.role,"is_active":x.is_active} for x in db.query(User).all()]
@app.patch("/api/admin/users/{user_id}")
def update_user(user_id:int,role:str|None=None,is_active:bool|None=None,u:User=Depends(roles("admin")),db:Session=Depends(get_db)):
    x=db.get(User,user_id)
    if not x: raise HTTPException(404,"Usuario no encontrado")
    if role is not None:
        if role not in ("user","moderator","admin"): raise HTTPException(422,"Rol inválido")
        x.role=role
    if is_active is not None: x.is_active=is_active
    db.commit(); return {"id":x.id,"role":x.role,"is_active":x.is_active}
@app.get("/api/moderation/publications")
def moderation(u:User=Depends(roles("admin","moderator")),db:Session=Depends(get_db)):
    q=db.query(Publication)
    if u.role=="moderator":
        ids=[a.company_id for a in db.query(Assignment).filter_by(user_id=u.id).all()]
        q=q.filter(Publication.company_id.in_(ids))
    return [{"id":p.id,"title":p.title,"status":p.status,"company_id":p.company_id} for p in q.all()]
@app.patch("/api/moderation/publications/{pub_id}")
def moderate(pub_id:int,status:str,u:User=Depends(roles("admin","moderator")),db:Session=Depends(get_db)):
    if status not in ("published","rejected","inactive"): raise HTTPException(422,"Estado inválido")
    p=db.get(Publication,pub_id)
    if not p: raise HTTPException(404,"Publicación no encontrada")
    if u.role=="moderator" and not db.query(Assignment).filter_by(user_id=u.id,company_id=p.company_id).first(): raise HTTPException(403,"Empresa no asignada")
    p.status=status
    if status=="inactive": p.is_active=False
    db.commit(); return {"id":p.id,"status":p.status}
