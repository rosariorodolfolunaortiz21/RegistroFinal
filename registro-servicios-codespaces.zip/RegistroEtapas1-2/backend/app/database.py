import time
from sqlalchemy import create_engine,text
from sqlalchemy.orm import sessionmaker,DeclarativeBase
from .config import settings
engine=create_engine(settings.database_url,pool_pre_ping=True,connect_args={"connect_timeout":5})
SessionLocal=sessionmaker(bind=engine,autoflush=False,autocommit=False)
class Base(DeclarativeBase): pass
def get_db():
    db=SessionLocal()
    try: yield db
    finally: db.close()
def wait_db():
    error=None
    for _ in range(20):
        try:
            with engine.connect() as c: c.execute(text("SELECT 1"))
            return
        except Exception as e:
            error=e; time.sleep(2)
    raise RuntimeError(f"PostgreSQL no disponible: {error}")
