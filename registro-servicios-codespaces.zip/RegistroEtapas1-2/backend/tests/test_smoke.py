def test_project_has_expected_files():
    from pathlib import Path
    assert Path("app/main.py").exists()
    assert Path("app/models.py").exists()
