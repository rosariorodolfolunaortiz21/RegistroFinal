# Arquitectura

- `frontend`: Nginx sirve HTML/CSS/JavaScript en el puerto 8080 y enruta `/api/` hacia `backend:8000`.
- `backend`: FastAPI, SQLAlchemy, JWT y Argon2. Puerto 8000; Swagger en `/docs`.
- `db`: PostgreSQL 16 con volumen persistente. El backend conecta por el hostname Docker `db`, nunca por `localhost`.
- `moderator_assignments`: relación única entre usuario moderador y empresa.
- `publications`: estados `pending`, `published`, `rejected` e inactivación lógica.

El esquema se crea en el arranque y el administrador inicial se crea desde variables de entorno. Para producción se recomienda migraciones Alembic, pruebas de carga, cookies seguras o una estrategia de almacenamiento de tokens más robusta, TLS y revisión de seguridad.
